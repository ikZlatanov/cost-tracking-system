module SessionHelper
  def login_as(email:, password:)
    post login_path, params: {
      email: email,
      password: password
    }
  end
end